/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latres;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Andra
 */
public class DBConnect {
    private static Connection config;
    
    public static Connection dbconfig(){
        try{
            String url = "jdbc:mysql://localhost/latrespbo";
            String user = "root";
            String pass = "";
            Class.forName("com.mysql.jdbc.Driver");
            config = DriverManager.getConnection(url, user, pass);
        }catch(SQLException e){
            System.out.println("Koneksi database gagal " + e.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
        return config;
    }
    
}
